<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Косарев Антон</title>
</head>
<body>
    <h1>Лабораторные работы</h1>
    <h2>студента гр. ПИ-320 Косарева Антона </h2>
    
    <ul>
        <li><a href = "LR1/index.html">Лабораторная работа №1</a></li>
        <li><a href = "LR2/Lab2.html">Лабораторная работа №2</a></li>
        <li><a href = "LR3/lab3.html">Лабораторная работа №3</a></li>
        <li><a href = "LR4/lab4_1.html">Лабораторная работа №4</a></li>
        <li><a href = "LR5/lab5.html">Лабораторная работа №5</a></li>
    </ul>
</body>
</html>